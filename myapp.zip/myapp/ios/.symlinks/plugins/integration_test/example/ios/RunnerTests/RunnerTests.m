// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#import <IntegrationTest/IntegrationTestIosTest.h>
#import <XCTest/XCTest.h>

INTEGRATION_TEST_IOS_RUNNER(RunnerTests)
