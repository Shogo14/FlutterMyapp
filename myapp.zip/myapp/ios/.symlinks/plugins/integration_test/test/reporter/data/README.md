Files in this directory are not invoked directly by the test command.

They are used as inputs for the other test files outside of this directory, so
that failures can be tested.